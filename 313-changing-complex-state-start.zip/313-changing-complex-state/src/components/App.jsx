import React from "react";

function App() {
  return (
    <div className="container">
      <h1>Hello</h1>
      <form>
        <input name="fName" placeholder="First Name" />
        <input name="lName" placeholder="Last Name" />
        <button>Submit</button>
      </form>
    </div>
  );
}

export default App;
